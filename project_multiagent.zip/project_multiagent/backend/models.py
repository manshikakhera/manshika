import uuid
from datetime import datetime
from sqlalchemy import Column, String, DateTime, ForeignKey , Integer , Text , JSON , Enum as SAEnum
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from database import Base 
import enum


try:
    from pgvector.sqlalchemy import Vector
    PGVECTOR_AVAILABLE = True
except ImportError:
    PGVECTOR_AVAILABLE = False
    Vector = None
     
class ProjectStatus(enum.Enum):
    pending = "pending"
    processing = "processing"
    completed = "completed"
    failed = "failed"

class User(Base):
    __tablename__ = "users"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    email = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    projects = relationship("Project", back_populates="owner", cascade="all, delete-orphan")
    
class Project(Base):
    __tablename__ = "projects"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String, nullable=False)
    description = Column(Text)
    status = Column(SAEnum(ProjectStatus,name ="projectstatus"), default=ProjectStatus.pending)
    project_metadata = Column(JSON)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    personas = Column(JSON , nullable= False)
    source_type = Column(String , nullable= True)
    source_path = Column(String , nullable= True)
    codechunks = relationship("Codechunk", back_populates="project") 
    owner_id = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    owner = relationship("User", back_populates="projects")

def _make_embedding_column(dim: int = 1536):
    if PGVECTOR_AVAILABLE and Vector is not None:
        return Column(Vector(1536), nullable=False)
    else:
        return Column(JSON , nullable=False)
    
class Codechunk(Base):
    __tablename__ = "codechunks"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    project_id = Column(UUID(as_uuid=True), ForeignKey("projects.id"))
    file_path = Column(String, nullable=False)
    start_line = Column(Integer, nullable=False)
    end_line = Column(Integer, nullable=False)
    chunk_type = Column(String, nullable=False)
    name = Column(String, nullable=True)
    content = Column(Text, nullable=False)
    embedding = _make_embedding_column()
    project = relationship("Project", back_populates="codechunks")