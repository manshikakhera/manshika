import asyncio
from typing import Optional

_queue: dict[str,asyncio.Queue] = {}
from pydantic import BaseModel

class ProgressUpdate(BaseModel):
    status: str
    message: str
    percent: float

def get_or_create_queue(project_id: str) -> asyncio.Queue:
    if project_id not in _queue:
        _queue[project_id] = asyncio.Queue()
    return _queue[project_id]

def remove_queue(project_id: str) -> None:
    _queue.pop(project_id, None)


class ProgressEmitter:
    
    def __init__(self, project_id: str):
        self.project_id = project_id
        self.queue = get_or_create_queue(project_id)

    async def emit(self ,event_type: str, message: str = None, percent: float = None, file: Optional[str] = None):
        event ={
            "type": event_type,
            "message": message,
            "percent": percent,
            "file": file
        } 
        if file is not None:
            event["file"] = file
        await self.queue.put(event)
        
    async def close(self) -> None:
        await self.queue.put(None)  # Sentinel value to indicate completion
              