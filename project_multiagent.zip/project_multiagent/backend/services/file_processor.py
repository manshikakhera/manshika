import asyncio
import os
import sys
import shutil
import tempfile
import zipfile
from pathlib import Path
from typing import List, Optional

from sqlalchemy.orm import Session


def _ensure_agents_importable() -> None:
    """Add the parent of agents/ directory to sys.path.
    Works for both Docker (/app/services → /app/agents)
    and local dev (backend/services → ../../agents → Project/agents)."""
    here = os.path.dirname(os.path.abspath(__file__))
    for steps_up in (1, 2):
        candidate = os.path.abspath(os.path.join(here, *(['..'] * steps_up), 'agents'))
        if os.path.isdir(candidate):
            parent = os.path.dirname(candidate)
            if parent not in sys.path:
                sys.path.insert(0, parent)
            # Local dev: also add backend/ so agents can import services.*
            backend = os.path.join(parent, 'backend')
            if os.path.isdir(backend) and backend not in sys.path:
                sys.path.insert(0, backend)
            return

from models import Codechunk, Project, ProjectStatus
from services.progress import ProgressEmitter

try:
    import openai as _openai_module

    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False
    _openai_module = None

CHUNK_SIZE = 100
CHUNK_OVERLAP = 10
EMBEDDING_DIM = 1536


class FileProcessor:
    SKIP_DIRS = {
        ".git",
        "node_modules",
        "__pycache__",
        ".venv",
        "venv",
        "dist",
        "build",
        ".next",
    }
    CODE_EXTENSIONS = {
        ".py",
        ".js",
        ".ts",
        ".java",
        ".cpp",
        ".c",
        ".cs",
        ".go",
        ".rb",
        ".php",
        ".rs",
        ".swift",
        ".kt",
        ".kts",
        ".scala",
        ".lua",
        ".sh",
        ".ps1",
        ".dart",
        ".m",
        ".mm",
        ".sql",
        ".html",
        ".css",
        ".json",
        ".xml",
        ".yml",
        ".yaml",
    }

    async def process_project(
        self,
        project_id: str,
        source_path: str,
        db: Session,
        emitter: ProgressEmitter,
    ) -> None:
        temp_dir: Optional[str] = None
        try:
            await emitter.emit("progress", "Starting file processing", 0)
            work_dir, temp_dir = await asyncio.to_thread(self._resolve_source, source_path)

            code_files = await asyncio.to_thread(self._collect_files, work_dir)
            if not code_files:
                raise ValueError("No code files found in the provided source.")

            await emitter.emit("progress", f"Found {len(code_files)} code files.", 10)

            project_type = await asyncio.to_thread(self._detect_project_type, work_dir)
            await emitter.emit("progress", f"Detected project type: {project_type}", 15)

            all_chunks: List[dict] = []
            total_files = len(code_files)
            for idx, file_path in enumerate(code_files, start=1):
                rel_path = str(Path(file_path).relative_to(work_dir))
                percent = 15 + (idx / max(total_files, 1)) * 40
                await emitter.emit(
                    "progress",
                    f"Processing file {idx}/{total_files}: {rel_path}",
                    percent,
                    file=rel_path,
                )

                try:
                    content = Path(file_path).read_text(encoding="utf-8", errors="replace")
                except Exception:
                    await emitter.emit("warning", f"Failed to read file: {rel_path}", percent)
                    continue

                chunks = self._chunk_file(content, rel_path)
                all_chunks.extend(chunks)
                await asyncio.sleep(0)

            if not all_chunks:
                raise ValueError("No code chunks could be extracted from the source.")

            await emitter.emit("progress", f"Created {len(all_chunks)} code chunks.", 58)

            embeddings = await self._generate_embeddings(
                [chunk["content"] for chunk in all_chunks],
                emitter,
            )

            await asyncio.to_thread(self._replace_chunks, db, project_id, all_chunks, embeddings)
            await emitter.emit("progress", "Saved code chunks. Starting agent pipeline...", 65)

            _ensure_agents_importable()
            from agents.orchestrator import run_agents

            results = await run_agents(project_id=project_id, db=db, emitter=emitter)
            if not results:
                raise ValueError("Agent pipeline did not return results.")

            await emitter.emit("completed", "Project processing completed successfully.", 100)
        except Exception as exc:
            await self._mark_failed(db, project_id, str(exc))
            await emitter.emit("failed", str(exc), 100)
            raise
        finally:
            if temp_dir and os.path.exists(temp_dir):
                shutil.rmtree(temp_dir, ignore_errors=True)
            await emitter.close()

    def _resolve_source(self, source_path: str) -> tuple[str, Optional[str]]:
        if source_path.endswith(".zip") or zipfile.is_zipfile(source_path):
            temp_dir = tempfile.mkdtemp(prefix="codeanalysis_")
            with zipfile.ZipFile(source_path, "r") as zip_ref:
                zip_ref.extractall(temp_dir)

            entries = os.listdir(temp_dir)
            if len(entries) == 1:
                candidate = os.path.join(temp_dir, entries[0])
                if os.path.isdir(candidate):
                    return candidate, temp_dir
            return temp_dir, temp_dir
        return source_path, None

    def _collect_files(self, root: str) -> List[str]:
        files: List[str] = []
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = [directory for directory in dirnames if directory not in self.SKIP_DIRS]
            for filename in filenames:
                ext = Path(filename).suffix.lower()
                if ext in self.CODE_EXTENSIONS:
                    files.append(os.path.join(dirpath, filename))
        return files

    def _detect_project_type(self, root: str) -> str:
        markers = {
            "package.json": "Node.js/Javascript",
            "requirements.txt": "Python",
            "pyproject.toml": "Python",
            "go.mod": "Go",
            "pom.xml": "Java(Maven)",
            "build.gradle": "Java(Gradle)",
            "Cargo.toml": "Rust",
            "Gemfile": "Ruby",
            "composer.json": "PHP",
            ".csproj": "C#",
        }
        for marker, label in markers.items():
            if marker.startswith("."):
                for dirpath, _, filenames in os.walk(root):
                    if any(file.endswith(marker) for file in filenames):
                        return label
            elif os.path.exists(os.path.join(root, marker)):
                return label
        return "Unknown"

    def _chunk_file(self, content: str, rel_path: str) -> List[dict]:
        return self._chunk_by_line(content, rel_path)

    def _chunk_by_line(self, content: str, rel_path: str) -> List[dict]:
        lines = content.splitlines()
        if not lines:
            return []

        chunks: List[dict] = []
        start = 0
        chunk_index = 0

        while start < len(lines):
            end = min(start + CHUNK_SIZE, len(lines))
            chunk_content = "\n".join(lines[start:end])
            chunks.append(
                {
                    "file_path": rel_path,
                    "start_line": start + 1,
                    "end_line": end,
                    "chunk_type": "code",
                    "name": f"{rel_path}_chunk{chunk_index}",
                    "content": chunk_content,
                }
            )
            chunk_index += 1
            next_start = end - CHUNK_OVERLAP
            start = next_start if next_start > start else start + 1

        return chunks

    async def _generate_embeddings(
        self,
        texts: List[str],
        emitter: ProgressEmitter,
    ) -> List[List[float]]:
        openai_key = os.getenv("OPENAI_API_KEY")
        if not texts:
            return []
        if not openai_key or not OPENAI_AVAILABLE:
            await emitter.emit(
                "warning",
                "OpenAI embeddings unavailable; using zero vectors.",
                62,
            )
            return [[0.0] * EMBEDDING_DIM for _ in texts]

        client = _openai_module.AsyncOpenAI(api_key=openai_key)
        embeddings: List[List[float]] = []
        batch_size = 100
        total_batches = max(1, (len(texts) + batch_size - 1) // batch_size)

        for batch_start in range(0, len(texts), batch_size):
            batch = texts[batch_start : batch_start + batch_size]
            current_batch = batch_start // batch_size + 1
            percent = 58 + (current_batch / total_batches) * 6

            await emitter.emit(
                "progress",
                f"Generating embeddings for batch {current_batch}/{total_batches}",
                percent,
            )
            try:
                response = await client.embeddings.create(
                    model="text-embedding-3-small",
                    input=batch,
                )
                embeddings.extend(item.embedding for item in response.data)
            except Exception as exc:
                await emitter.emit(
                    "warning",
                    f"Embedding batch {current_batch} failed: {exc}. Using zero vectors.",
                    percent,
                )
                embeddings.extend([[0.0] * EMBEDDING_DIM for _ in batch])

        return embeddings

    def _replace_chunks(
        self,
        db: Session,
        project_id: str,
        chunks: List[dict],
        embeddings: List[List[float]],
    ) -> None:
        db.query(Codechunk).filter(Codechunk.project_id == project_id).delete()
        for chunk_data, embedding in zip(chunks, embeddings):
            db.add(
                Codechunk(
                    project_id=project_id,
                    file_path=chunk_data["file_path"],
                    start_line=chunk_data["start_line"],
                    end_line=chunk_data["end_line"],
                    chunk_type=chunk_data["chunk_type"],
                    name=chunk_data["name"],
                    content=chunk_data["content"],
                    embedding=embedding,
                )
            )
        db.commit()

    async def _mark_failed(self, db: Session, project_id: str, error_message: str) -> None:
        project = db.query(Project).filter(Project.id == project_id).first()
        if project:
            project.status = ProjectStatus.failed
            project.project_metadata = {"error": error_message}
            db.commit()
