
import asyncio
import json
import os
import shutil
from typing import Optional

import aiofiles
from fastapi import APIRouter, BackgroundTasks, Depends, File, HTTPException, Query, UploadFile, status
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from auth import get_current_user
from database import SessionLocal, get_db
from models import Project, ProjectStatus, User
from schemas import ProjectCreate, ProjectOut
from services.file_processor import FileProcessor
from services.progress import ProgressEmitter, get_or_create_queue, remove_queue

router = APIRouter(prefix="/projects", tags=["projects"])

UPLOAD_DIR = os.getenv("UPLOAD_DIR", "/tmp/codeanalysis_uploads")
MAX_ZIP_BYTES = 100 * 1024 * 1024


def _get_project_or_404(db: Session, project_id: str, owner_id) -> Project:
    project = (
        db.query(Project)
        .filter(Project.id == project_id, Project.owner_id == owner_id)
        .first()
    )
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    return project


async def _run_processing(project_id: str, source_path: str) -> None:
    db = SessionLocal()
    try:
        emitter = ProgressEmitter(project_id)
        processor = FileProcessor()
        await processor.process_project(
            project_id=project_id,
            source_path=source_path,
            db=db,
            emitter=emitter,
        )
    except Exception as exc:
        print(f"[background] project {project_id} failed: {exc}")
    finally:
        db.close()


@router.get("/", response_model=list[ProjectOut])
def list_projects(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    return (
        db.query(Project)
        .filter(Project.owner_id == current_user.id)
        .order_by(Project.created_at.desc())
        .all()
    )


@router.post("/", response_model=ProjectOut, status_code=status.HTTP_201_CREATED)
def create_project(
    payload: ProjectCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    project = Project(
        owner_id=current_user.id,
        name=payload.name,
        description=payload.description,
        personas=payload.personas,
        source_type=payload.source_type,
    )
    db.add(project)
    db.commit()
    db.refresh(project)
    return project


@router.get("/{project_id}", response_model=ProjectOut)
def get_project(
    project_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    return _get_project_or_404(db, project_id, current_user.id)


@router.post("/{project_id}/upload", response_model=ProjectOut)
async def upload_project(
    project_id: str,
    background_tasks: BackgroundTasks,
    file: Optional[UploadFile] = File(default=None),
    github_url: Optional[str] = Query(default=None),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    project = _get_project_or_404(db, project_id, current_user.id)

    if project.status not in (ProjectStatus.pending, ProjectStatus.failed):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Project is already in '{project.status.value}' state.",
        )
    if file is None and not github_url:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="Provide either a ZIP file or a github_url query parameter.",
        )

    if file is not None:
        if not (file.filename or "").lower().endswith(".zip"):
            raise HTTPException(status_code=400, detail="Only ZIP files are accepted.")

        os.makedirs(UPLOAD_DIR, exist_ok=True)
        source_path = os.path.join(UPLOAD_DIR, f"{project_id}.zip")
        size = 0

        async with aiofiles.open(source_path, "wb") as out:
            while True:
                chunk = await file.read(65536)
                if not chunk:
                    break
                size += len(chunk)
                if size > MAX_ZIP_BYTES:
                    os.remove(source_path)
                    raise HTTPException(
                        status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                        detail="ZIP file exceeds 100 MB limit.",
                    )
                await out.write(chunk)

        project.source_type = "zip"
    else:
        try:
            import git
        except ImportError:
            raise HTTPException(
                status_code=status.HTTP_501_NOT_IMPLEMENTED,
                detail="GitPython is not installed; cannot clone repositories.",
            )

        os.makedirs(UPLOAD_DIR, exist_ok=True)
        source_path = os.path.join(UPLOAD_DIR, project_id)
        if os.path.isdir(source_path):
            shutil.rmtree(source_path)

        try:
            git.Repo.clone_from(github_url, source_path, depth=1)
        except git.GitCommandError as exc:
            raise HTTPException(status_code=400, detail=f"git clone failed: {exc}")

        project.source_type = "github"

    project.source_path = source_path
    project.status = ProjectStatus.processing
    project.project_metadata = None
    db.commit()
    db.refresh(project)

    get_or_create_queue(project_id)
    background_tasks.add_task(_run_processing, project_id, source_path)
    return project


@router.get("/{project_id}/progress")
async def project_progress(
    project_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    _get_project_or_404(db, project_id, current_user.id)
    queue = get_or_create_queue(project_id)

    async def event_generator():
        try:
            while True:
                try:
                    event = await asyncio.wait_for(queue.get(), timeout=15.0)
                except asyncio.TimeoutError:
                    yield ":keepalive\n\n"
                    continue

                if event is None:
                    yield 'data: {"type":"done"}\n\n'
                    break

                yield f"data: {json.dumps(event)}\n\n"
        finally:
            remove_queue(project_id)

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


@router.get("/{project_id}/analysis")
def get_analysis(
    project_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    project = _get_project_or_404(db, project_id, current_user.id)

    if project.status != ProjectStatus.completed:
        raise HTTPException(
            status_code=425,
            detail=f"Analysis not ready; status: {project.status.value}",
        )

    return project.project_metadata or {}
