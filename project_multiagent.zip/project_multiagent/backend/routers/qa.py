"""Q&A endpoint — ask natural language questions about an analyzed codebase."""
import os
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from auth import get_current_user
from database import get_db
from models import Codechunk, Project, ProjectStatus, User

router = APIRouter(prefix="/projects", tags=["qa"])


class QARequest(BaseModel):
    question: str


class QAResponse(BaseModel):
    answer: str
    references: list


@router.post("/{project_id}/qa", response_model=QAResponse)
async def ask_question(
    project_id: str,
    payload: QARequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    project = (
        db.query(Project)
        .filter(Project.id == project_id, Project.owner_id == current_user.id)
        .first()
    )
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    if project.status != ProjectStatus.completed:
        raise HTTPException(status_code=425, detail="Analysis not complete yet")

    openai_key = os.getenv("OPENAI_API_KEY")
    if not openai_key:
        raise HTTPException(status_code=503, detail="OpenAI API key not configured")

    # Keyword-based chunk retrieval (works without vector search)
    question_lower = payload.question.lower()
    keywords = [w for w in question_lower.split() if len(w) > 3]

    all_chunks = (
        db.query(Codechunk).filter(Codechunk.project_id == project_id).all()
    )

    def relevance(chunk) -> int:
        text = (chunk.content + " " + chunk.file_path).lower()
        return sum(1 for kw in keywords if kw in text)

    top_chunks = sorted(all_chunks, key=relevance, reverse=True)[:6]

    context_text = "\n\n".join(
        f"File: {c.file_path} (lines {c.start_line}-{c.end_line})\n{c.content[:500]}"
        for c in top_chunks
    )

    metadata    = project.project_metadata or {}
    understanding = metadata.get("understanding", {})

    import openai
    client = openai.AsyncOpenAI(api_key=openai_key)

    response = await client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {
                "role": "system",
                "content": (
                    f"You are a code assistant for the project '{project.name}'. "
                    f"Purpose: {understanding.get('project_purpose', 'unknown')}. "
                    f"Tech stack: {', '.join(understanding.get('tech_stack', []))}. "
                    "Answer concisely based on the provided code context. "
                    "Include file references when relevant."
                ),
            },
            {
                "role": "user",
                "content": f"Question: {payload.question}\n\nRelevant code:\n{context_text}",
            },
        ],
        max_tokens=800,
        temperature=0.3,
    )

    answer = response.choices[0].message.content.strip()
    references = [
        {"file": c.file_path, "lines": f"{c.start_line}-{c.end_line}"}
        for c in top_chunks
        if relevance(c) > 0
    ]

    return QAResponse(answer=answer, references=references)
