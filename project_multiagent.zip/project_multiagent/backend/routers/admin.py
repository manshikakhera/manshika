"""Admin-only endpoints: user/project management and system stats."""
import os
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from auth import get_current_user
from database import get_db
from models import Project, ProjectStatus, User
from schemas import ProjectOut, UserOut

router = APIRouter(prefix="/admin", tags=["admin"])

ADMIN_EMAIL = os.getenv("ADMIN_EMAIL", "admin@example.com")


def _require_admin(current_user: User = Depends(get_current_user)) -> User:
    if current_user.email != ADMIN_EMAIL:
        raise HTTPException(status_code=403, detail="Admin access required")
    return current_user


@router.get("/stats")
def get_stats(
    _admin: User = Depends(_require_admin),
    db: Session = Depends(get_db),
):
    total_users    = db.query(User).count()
    total_projects = db.query(Project).count()
    completed      = db.query(Project).filter(Project.status == ProjectStatus.completed).count()
    failed         = db.query(Project).filter(Project.status == ProjectStatus.failed).count()
    processing     = db.query(Project).filter(Project.status == ProjectStatus.processing).count()
    return {
        "total_users":         total_users,
        "total_projects":      total_projects,
        "completed_projects":  completed,
        "failed_projects":     failed,
        "processing_projects": processing,
        "completion_rate":     round(completed / max(total_projects, 1) * 100, 1),
    }


@router.get("/users", response_model=list[UserOut])
def list_users(
    _admin: User = Depends(_require_admin),
    db: Session = Depends(get_db),
):
    return db.query(User).order_by(User.created_at.desc()).all()


@router.get("/projects", response_model=list[ProjectOut])
def list_all_projects(
    _admin: User = Depends(_require_admin),
    db: Session = Depends(get_db),
):
    return db.query(Project).order_by(Project.created_at.desc()).all()


@router.delete("/users/{user_id}")
def delete_user(
    user_id: str,
    _admin: User = Depends(_require_admin),
    db: Session = Depends(get_db),
):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    db.delete(user)
    db.commit()
    return {"message": "User deleted"}


@router.delete("/projects/{project_id}")
def delete_project(
    project_id: str,
    _admin: User = Depends(_require_admin),
    db: Session = Depends(get_db),
):
    project = db.query(Project).filter(Project.id == project_id).first()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    db.delete(project)
    db.commit()
    return {"message": "Project deleted"}
