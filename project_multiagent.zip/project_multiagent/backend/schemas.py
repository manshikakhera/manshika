from __future__ import annotations
import uuid 
from datetime import datetime
from typing import List, Optional , Literal

from pydantic import BaseModel, EmailStr, Field

class UserCreate(BaseModel):
    email: EmailStr
    password: str = Field(..., min_length=8)

class UserOut(BaseModel):
    id: uuid.UUID
    email: EmailStr
    role: str = "user"
    created_at: datetime
    
    class Config:
        orm_mode = True 
        
class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"

class ProjectCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    description: Optional[str] = None
    personas: List[str]
    source_type: Optional[str] = None
    github_url: Optional[str] = None

class ProjectOut(BaseModel):
    id: uuid.UUID
    owner_id: uuid.UUID
    name: str
    description: Optional[str]
    status: str
    personas: List[str]
    source_type: Optional[str]
    source_path: Optional[str]
    project_metadata: Optional[dict]
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True
class ProgressUpdate(BaseModel):
    status: Literal["pending", "processing", "completed", "failed"]
    message: Optional[str] = None
    percent: float = Field(..., ge=0, le=100)
    file : Optional[str] = None
