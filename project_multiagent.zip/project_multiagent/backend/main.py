import os 
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from database import Base, engine , enable_pgvector 
from routers import auth as auth_router
from routers import projects as projects_router
from routers import qa as qa_router
from routers import admin as admin_router




app = FastAPI(
    title = "code analysis API", 
    description = "AI-powered code analysis and project management API built with FastAPI and PostgreSQL",
    version = "0.1.0"
)


app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)


app.include_router(auth_router.router)
app.include_router(projects_router.router)
app.include_router(qa_router.router)
app.include_router(admin_router.router)

@app.on_event("startup")
def startup():
    enable_pgvector(engine)
    Base.metadata.create_all(bind=engine) 
    print("Database tables created and pgvector enabled")

@app.get("/health")
def health():
    return {"status": "ok"}      
