"""
agents/orchestrator.py
──────────────────────
This is THE connection point between your existing backend code
and the new agent pipeline.

HOW IT CONNECTS TO YOUR EXISTING CODE
──────────────────────────────────────

  Your backend/services/file_processor.py calls this ONE function:

      from agents.orchestrator import run_agents   ← add this import
      await run_agents(project_id, db, emitter)    ← add this call

  It reads from tables you already have:
    ┌─────────────────────────────────────────────────────┐
    │  backend/models.py                                  │
    │    Project     → name, description, personas        │
    │    Codechunk   → file_path, name, content           │
    └─────────────────────────────────────────────────────┘

  It writes results back to:
    ┌─────────────────────────────────────────────────────┐
    │  Project.project_metadata  (your existing JSON col) │
    │  Project.status = "completed"                       │
    └─────────────────────────────────────────────────────┘

AGENT PIPELINE
──────────────
  Coordinator  → decides which agents to run
      ↓
  ParserAgent  → extracts file structure from Codechunk records
      ↓
  UnderstandingAgent → understands what the project does
      ↓
  PersonaAgent("SDE") → technical analysis  (if SDE in personas)
  PersonaAgent("PM")  → product analysis    (if PM  in personas)
      ↓
  Results saved to Project.project_metadata

PROGRESS EVENTS (SSE)
─────────────────────
  Every agent emits progress events via ProgressEmitter so the
  frontend progress bar keeps updating during agent runs.

  Percentages used:
    20%  → chunks loaded
    25%  → coordinator starting
    30%  → coordinator done
    35%  → parser starting
    45%  → parser done
    50%  → understanding starting
    60%  → understanding done
    65%  → SDE agent starting
    73%  → SDE done
    75%  → PM agent starting
    83%  → PM done
    95%  → results saved
"""

import os
import sys
import json

# ── Make backend/ importable from both Docker and local dev ──────────────────
_AGENTS_DIR  = os.path.dirname(os.path.abspath(__file__))
_PROJECT_DIR = os.path.dirname(_AGENTS_DIR)
if _PROJECT_DIR not in sys.path:
    sys.path.insert(0, _PROJECT_DIR)
_BACKEND_DIR = os.path.join(_PROJECT_DIR, "backend")
if os.path.isdir(_BACKEND_DIR) and _BACKEND_DIR not in sys.path:
    sys.path.insert(0, _BACKEND_DIR)
# ─────────────────────────────────────────────────────────────────────────────

from sqlalchemy.orm import Session
from models import Project, Codechunk, ProjectStatus
from services.progress import ProgressEmitter

from agents.coordinator_agent   import CoordinatorAgent
from agents.parser_agent        import ParserAgent
from agents.understanding_agent import UnderstandingAgent
from agents.persona_agent       import PersonaAgent
from agents.diagram_agent       import DiagramAgent


async def run_agents(
    project_id: str,
    db: Session,
    emitter: ProgressEmitter,
) -> dict:
    """
    Main entry point called by file_processor.py after chunks are saved.

    Returns the full results dict (also persisted to Project.project_metadata).
    """

    # ── 1. Load Project and Codechunks from DB ───────────────────────────
    project = db.query(Project).filter(Project.id == project_id).first()
    if not project:
        await emitter.emit("error", f"Project {project_id} not found in DB.", 100)
        return {}

    chunks = (
        db.query(Codechunk)
        .filter(Codechunk.project_id == project_id)
        .all()
    )

    await emitter.emit(
        "agent",
        f"Loaded {len(chunks)} code chunks. Starting agent pipeline...",
        20,
    )

    # ── 2. Shared context dict ────────────────────────────────────────────
    # Every agent receives this dict and adds its results to it.
    context: dict = {
        "project_id": project_id,
        "project":    project,          # ORM object
        "chunks":     chunks,           # list of Codechunk ORM objects
        "personas":   project.personas or [],
    }

    # ── 3. Coordinator ────────────────────────────────────────────────────
    try:
        result = await CoordinatorAgent(emitter=emitter).run(context)
        context.update(result)
    except Exception as exc:
        await emitter.emit("warning", f"Coordinator failed ({exc}). Using defaults.", 30)
        personas = project.personas or []
        context["plan"] = {
            "run_parser":        True,
            "run_understanding": True,
            "run_sde": "SDE" in personas or not personas,
            "run_pm":  "PM"  in personas or not personas,
        }
        context["exec_summary"] = ""

    plan = context.get("plan", {})

    # ── 4. Parser Agent ───────────────────────────────────────────────────
    if plan.get("run_parser", True):
        try:
            result = await ParserAgent(emitter=emitter).run(context)
            context.update(result)
        except Exception as exc:
            await emitter.emit("warning", f"Parser failed ({exc}).", 45)
            context["structure"] = {"files": [], "summary": "Parser failed."}

    # ── 5. Understanding Agent ────────────────────────────────────────────
    if plan.get("run_understanding", True):
        try:
            result = await UnderstandingAgent(emitter=emitter).run(context)
            context.update(result)
        except Exception as exc:
            await emitter.emit("warning", f"Understanding agent failed ({exc}).", 60)
            context["understanding"] = {"project_purpose": "Could not determine."}

    # ── 6. Persona Agents ─────────────────────────────────────────────────
    personas = project.personas or []
    run_sde  = plan.get("run_sde", "SDE" in personas or not personas)
    run_pm   = plan.get("run_pm",  "PM"  in personas or not personas)

    if run_sde:
        try:
            result = await PersonaAgent(persona="SDE", emitter=emitter).run(context)
            context.update(result)
        except Exception as exc:
            await emitter.emit("warning", f"SDE agent failed ({exc}).", 73)
            context["sde_analysis"] = {"error": str(exc)}

    if run_pm:
        try:
            result = await PersonaAgent(persona="PM", emitter=emitter).run(context)
            context.update(result)
        except Exception as exc:
            await emitter.emit("warning", f"PM agent failed ({exc}).", 83)
            context["pm_analysis"] = {"error": str(exc)}

    # ── 7. Diagram Agent ──────────────────────────────────────────────────
    try:
        result = await DiagramAgent(emitter=emitter).run(context)
        context.update(result)
    except Exception as exc:
        await emitter.emit("warning", f"Diagram agent failed ({exc}).", 92)
        context["diagrams"] = {}

    # ── 8. Build final results ────────────────────────────────────────────
    final_results = {
        "exec_summary":  context.get("exec_summary", ""),
        "plan":          context.get("plan", {}),
        "structure":     context.get("structure", {}),
        "understanding": context.get("understanding", {}),
        "sde_analysis":  context.get("sde_analysis"),
        "pm_analysis":   context.get("pm_analysis"),
        "diagrams":      context.get("diagrams", {}),
    }

    # ── 8. Save to Project.project_metadata ──────────────────────────────
    # project_metadata is already a JSON column on your Project model.
    # No DB migration needed — it already exists.
    try:
        project.project_metadata = final_results
        project.status = ProjectStatus.completed
        db.commit()
        await emitter.emit("agent", "All agents done. Results saved.", 95)
    except Exception as exc:
        await emitter.emit("warning", f"Failed to save results to DB: {exc}", 95)

    return final_results
