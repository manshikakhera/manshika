"""
agents/parser_agent.py
──────────────────────
ROLE  : Reads the stored Codechunk records and extracts the
        structural map of the codebase (files, classes, functions).

READS FROM CONTEXT:
  - context["chunks"]   → list of Codechunk ORM objects
    (loaded from backend/models.py → Codechunk table)

WRITES TO CONTEXT:
  - context["structure"] → used by UnderstandingAgent and PersonaAgents
    {
      "files": [{"path": "...", "type": "...", "components": [...]}],
      "summary": "short plain-english layout description"
    }

NOTE: We only send file paths + component names to OpenAI,
      NOT the full code content. This keeps the prompt small and cheap.
"""

import os, sys, json

_AGENTS_DIR  = os.path.dirname(os.path.abspath(__file__))
_PROJECT_DIR = os.path.dirname(_AGENTS_DIR)
if _PROJECT_DIR not in sys.path:
    sys.path.insert(0, _PROJECT_DIR)
_BACKEND_DIR = os.path.join(_PROJECT_DIR, "backend")
if os.path.isdir(_BACKEND_DIR) and _BACKEND_DIR not in sys.path:
    sys.path.insert(0, _BACKEND_DIR)

from agents.base_agent import BaseAgent


class ParserAgent(BaseAgent):

    name = "Code Parser"
    system_prompt = """\
You are a code structure analyst.
Given a map of file paths and their component names from a software project, extract:
1. A list of unique files with their type and components
2. A short plain-English layout summary (max 3 sentences)

Respond ONLY in valid JSON — no markdown fences, no extra text:
{
  "files": [
    {
      "path": "relative/path/to/file.py",
      "type": "python|javascript|typescript|other",
      "components": ["ClassName", "function_name"]
    }
  ],
  "summary": "short description of the project layout"
}
"""

    async def run(self, context: dict) -> dict:
        chunks = context.get("chunks", [])

        await self._emit("Analyzing code structure...", percent=35)

        if not chunks:
            await self._emit("No chunks — skipping structure analysis.", percent=40)
            return {
                "agent_name": self.name,
                "structure":  {"files": [], "summary": "No code chunks available."},
            }

        # ── Build file → components map from Codechunk ORM objects ──────
        # Codechunk fields used: file_path, name  (backend/models.py)
        file_map: dict[str, list] = {}
        for chunk in chunks:
            path = getattr(chunk, "file_path", None) or (chunk.get("file_path") if isinstance(chunk, dict) else "unknown")
            name = getattr(chunk, "name",      None) or (chunk.get("name")      if isinstance(chunk, dict) else "")
            if path not in file_map:
                file_map[path] = []
            if name and not name.endswith("_chunk0"):   # skip generic names
                file_map[path].append(name)

        # Limit to 80 files so prompt stays under ~2 k tokens
        limited = dict(list(file_map.items())[:80])

        prompt = f"""\
Files and components found in the codebase:

{json.dumps(limited, indent=2)}

Total files  : {len(file_map)}
Total chunks : {len(chunks)}

Extract the structure JSON now.
"""
        raw = await self._chat(prompt, model="gpt-4o-mini", max_tokens=2000)

        try:
            structure = json.loads(raw.strip())
        except json.JSONDecodeError:
            structure = {
                "files":   list(limited.keys()),
                "summary": raw[:400],
            }

        await self._emit(f"Structure analyzed — {len(file_map)} files.", percent=45)

        return {
            "agent_name": self.name,
            "structure":  structure,
        }
