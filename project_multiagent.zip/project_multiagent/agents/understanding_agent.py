"""
agents/understanding_agent.py
─────────────────────────────
ROLE  : Combines the structural map from ParserAgent with a sample
        of real code content to understand what the project actually does.

READS FROM CONTEXT:
  - context["structure"]  → from ParserAgent (file list + layout summary)
  - context["chunks"]     → picks top 10 meaningful chunks for code samples
    (Codechunk.content — backend/models.py)

WRITES TO CONTEXT:
  - context["understanding"] → used by both PersonaAgents
    {
      "project_purpose" : "...",
      "tech_stack"      : ["FastAPI", "PostgreSQL", ...],
      "architecture"    : "monolith|microservices|...",
      "core_features"   : ["feature 1", ...],
      "entry_points"    : ["main.py", ...],
      "complexity"      : "low|medium|high",
      "complexity_reason": "..."
    }
"""

import os, sys, json

_AGENTS_DIR  = os.path.dirname(os.path.abspath(__file__))
_PROJECT_DIR = os.path.dirname(_AGENTS_DIR)
if _PROJECT_DIR not in sys.path:
    sys.path.insert(0, _PROJECT_DIR)
_BACKEND_DIR = os.path.join(_PROJECT_DIR, "backend")
if os.path.isdir(_BACKEND_DIR) and _BACKEND_DIR not in sys.path:
    sys.path.insert(0, _BACKEND_DIR)

from agents.base_agent import BaseAgent


class UnderstandingAgent(BaseAgent):

    name = "Understanding Agent"
    system_prompt = """\
You are a senior software architect.
Given a code project's structure and sample code snippets, produce a clear understanding.

Respond ONLY in valid JSON — no markdown fences, no extra text:
{
  "project_purpose"  : "1-2 sentences: what does this project do?",
  "tech_stack"       : ["FastAPI", "PostgreSQL", "React"],
  "architecture"     : "monolith|microservices|serverless|MVC|other",
  "core_features"    : ["feature 1", "feature 2"],
  "entry_points"     : ["main.py", "index.js"],
  "complexity"       : "low|medium|high",
  "complexity_reason": "one sentence explanation"
}
"""

    async def run(self, context: dict) -> dict:
        structure = context.get("structure", {})
        chunks    = context.get("chunks", [])

        await self._emit("Understanding project purpose and architecture...", percent=50)

        # ── Pick 10 representative code samples ──────────────────────────
        # Prefer chunks whose name looks like a real function/class
        # rather than a generic "file_chunk0" auto-name
        def is_meaningful(chunk) -> bool:
            name = getattr(chunk, "name", None) or (chunk.get("name", "") if isinstance(chunk, dict) else "")
            return bool(name) and "_chunk" not in name

        meaningful = [c for c in chunks if is_meaningful(c)]
        sample_pool = meaningful[:10] if len(meaningful) >= 10 else chunks[:10]

        code_samples = []
        for chunk in sample_pool:
            path    = getattr(chunk, "file_path", None) or (chunk.get("file_path", "?") if isinstance(chunk, dict) else "?")
            content = getattr(chunk, "content",   None) or (chunk.get("content",   "")  if isinstance(chunk, dict) else "")
            # Truncate each sample to keep total prompt ≤ ~4 k tokens
            code_samples.append(f"--- {path} ---\n{content[:300]}\n")

        prompt = f"""\
Project structure:
{json.dumps(structure, indent=2)[:2000]}

Sample code from the project:
{''.join(code_samples)[:3000]}

Produce the project understanding JSON now.
"""
        raw = await self._chat(prompt, model="gpt-4o-mini", max_tokens=1500)

        try:
            understanding = json.loads(raw.strip())
        except json.JSONDecodeError:
            understanding = {"project_purpose": raw[:400]}

        await self._emit(
            f"Understood: {understanding.get('project_purpose', '')[:80]}",
            percent=60,
        )

        return {
            "agent_name":    self.name,
            "understanding": understanding,
        }
