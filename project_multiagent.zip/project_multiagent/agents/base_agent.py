"""
agents/base_agent.py
────────────────────
Your folder structure:
    PROJECT/
      agents/          ← this file lives here
      backend/
        services/
          progress.py  ← ProgressEmitter lives here

Because agents/ is OUTSIDE backend/, we add backend/ to sys.path
at the top of every agent file so imports resolve correctly.
"""

import os
import sys
from abc import ABC, abstractmethod
from typing import Optional

# ── Make backend/ importable from agents/ ──────────────────────────────────
# __file__ = PROJECT/agents/base_agent.py
# backend  = PROJECT/backend
_AGENTS_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJECT_DIR = os.path.dirname(_AGENTS_DIR)  # parent of agents/
if _PROJECT_DIR not in sys.path:
    sys.path.insert(0, _PROJECT_DIR)
_BACKEND_DIR = os.path.join(_PROJECT_DIR, "backend")
if os.path.isdir(_BACKEND_DIR) and _BACKEND_DIR not in sys.path:
    sys.path.insert(0, _BACKEND_DIR)
# ───────────────────────────────────────────────────────────────────────────

from openai import AsyncOpenAI
from backend.services.progress import ProgressEmitter

# ── Optional Langfuse tracing ───────────────────────────────────────────────
try:
    from langfuse import Langfuse
    _langfuse: Optional["Langfuse"] = Langfuse()
except Exception:
    _langfuse = None
# ───────────────────────────────────────────────────────────────────────────


class BaseAgent(ABC):
    """
    Every agent inherits from this.

    Provides:
      - OpenAI async client (gpt-4o-mini by default, gpt-4o for persona agents)
      - _emit()  → sends progress event to the SSE stream
      - _chat()  → calls OpenAI and returns text
      - run()    → abstract, each agent implements its own logic
    """

    name: str = "Base Agent"
    system_prompt: str = "You are a helpful assistant."

    def __init__(self, emitter: Optional[ProgressEmitter] = None):
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise RuntimeError("OPENAI_API_KEY environment variable is not set.")
        self.client  = AsyncOpenAI(api_key=api_key)
        self.emitter = emitter

    # ── Progress helper ─────────────────────────────────────────────────────
    async def _emit(self, message: str, percent: float) -> None:
        """Send a progress event so the frontend SSE bar updates."""
        if self.emitter:
            await self.emitter.emit(
                event_type="agent",
                message=f"[{self.name}] {message}",
                percent=percent,
            )

    # ── Core LLM call ────────────────────────────────────────────────────────
    async def _chat(
        self,
        user_message: str,
        model: str = "gpt-4o-mini",   # cheap model for parser/coordinator
        max_tokens: int = 2000,
        temperature: float = 0.3,
    ) -> str:
        messages = [
            {"role": "system", "content": self.system_prompt},
            {"role": "user",   "content": user_message},
        ]
        response = await self.client.chat.completions.create(
            model=model,
            temperature=temperature,
            max_tokens=max_tokens,
            messages=messages,
        )
        output = response.choices[0].message.content.strip()

        if _langfuse:
            try:
                _langfuse.generation(
                    name=self.name,
                    model=model,
                    input=messages,
                    output=output,
                    usage={
                        "input":  response.usage.prompt_tokens,
                        "output": response.usage.completion_tokens,
                    },
                )
            except Exception:
                pass  # never let tracing break the pipeline

        return output

    # ── Abstract interface ───────────────────────────────────────────────────
    @abstractmethod
    async def run(self, context: dict) -> dict:
        """
        Receives shared context dict, returns a dict that gets
        merged back into context by the orchestrator.

        Every agent must return at minimum:
        {
            "agent_name": self.name,
            "output":     <result>
        }
        """
