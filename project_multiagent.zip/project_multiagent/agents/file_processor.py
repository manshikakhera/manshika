"""
backend/services/file_processor.py
────────────────────────────────────
All bugs from code review fixed.
Connection to agents added at the bottom of _do_process().

KEY CHANGE — the one line that triggers Milestone 4:
    from agents.orchestrator import run_agents
    await run_agents(project_id, db, emitter)

This is called AFTER chunks are saved to pgvector.
The orchestrator then runs all agents and saves results to
Project.project_metadata automatically.
"""

import os
import sys
import asyncio
import zipfile
import shutil
import tempfile
from pathlib import Path
from typing import List, Optional

from sqlalchemy.orm import Session
from backend.models import Project, Codechunk, ProjectStatus
from backend.services.progress import ProgressEmitter

# ── Make agents/ importable from backend/ ────────────────────────────────────
# backend/services/file_processor.py
# agents/ is one level up from backend/
_AGENTS_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "agents"))
_PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
for _p in (_AGENTS_DIR, _PROJECT_ROOT):
    if _p not in sys.path:
        sys.path.insert(0, _p)
# ─────────────────────────────────────────────────────────────────────────────

try:
    import openai as _openai_module
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False
    _openai_module = None

try:
    import tree_sitter
    TREE_SITTER_AVAILABLE = True
except ImportError:
    TREE_SITTER_AVAILABLE = False
    tree_sitter = None

CHUNK_SIZE    = 100
CHUNK_OVERLAP = 10


class FileProcessor:

    SKIP_DIRS = {
        ".git", "node_modules", "__pycache__", ".venv", "venv",
        "dist", "build", ".next",
    }
    SKIP_EXTENSIONS = {
        ".exe", ".dll", ".bin", ".so", ".dylib", ".zip", ".tar", ".gz",
        ".jpg", ".jpeg", ".png", ".gif", ".bmp", ".pdf",
        ".pyc", ".pyo", ".pyd",
    }
    CODE_EXTENSIONS = {
        ".py", ".js", ".ts", ".java", ".cpp", ".c", ".cs", ".go",
        ".rb", ".php", ".rs", ".swift", ".kt", ".kts", ".scala",
        ".lua", ".sh", ".ps1", ".dart", ".m", ".mm", ".sql",
        ".html", ".css", ".json", ".xml", ".yml", ".yaml",
    }

    # ── Public entry point ────────────────────────────────────────────────
    async def process_project(
        self,
        project_id: str,
        source_path: str,
        db: Session,                 # FIX: was missing from original call sites
        emitter: ProgressEmitter,    # FIX: was missing from original call sites
    ) -> None:
        try:
            await self._do_process(project_id, source_path, db, emitter)
        except Exception as exc:
            await emitter.emit("failed", f"Processing error: {exc}", 100)
            project = db.query(Project).filter(Project.id == project_id).first()
            if project:
                project.status = ProjectStatus.failed
                db.commit()
            raise
        finally:
            await emitter.close()

    # ── Main pipeline ─────────────────────────────────────────────────────
    async def _do_process(
        self,
        project_id: str,
        source_path: str,
        db: Session,
        emitter: ProgressEmitter,
    ) -> None:
        await emitter.emit("processing", "Starting file processing...", 0)

        work_dir, temp_dir = await asyncio.to_thread(self._resolve_source, source_path)

        try:
            code_files = await asyncio.to_thread(self._collect_files, work_dir)

            # FIX: warning was emitted BEFORE code_files was collected in original
            if not code_files:
                await emitter.emit("warning", "No code files found in the provided source.", 10)
                return

            await emitter.emit("processing", f"Found {len(code_files)} code files.", 10)

            project_type = await asyncio.to_thread(self._detect_project_type, work_dir)
            await emitter.emit("processing", f"Project type: {project_type}", 12)

            # ── Chunking ──────────────────────────────────────────────────
            all_chunks: List[dict] = []
            total = len(code_files)

            for idx, file_path in enumerate(code_files):
                rel_path = str(Path(file_path).relative_to(work_dir))
                pct      = 12 + (idx / max(total, 1)) * 30   # 12 → 42

                await emitter.emit("processing", f"Chunking {idx + 1}/{total}: {rel_path}", pct)

                try:
                    content = Path(file_path).read_text(errors="replace")
                except Exception:
                    await emitter.emit("warning", f"Could not read: {rel_path}", pct)
                    continue

                all_chunks.extend(self._chunk_file(content, rel_path))
                await asyncio.sleep(0)   # yield event loop

            await emitter.emit("processing", f"Chunking complete — {len(all_chunks)} chunks.", 42)

            # ── Embeddings ────────────────────────────────────────────────
            texts      = [c["content"] for c in all_chunks]
            embeddings = await self._generate_embeddings(texts, emitter)

            await emitter.emit("processing", "Saving chunks to database...", 55)

            # FIX: argument order was (project_id, chunks, embeddings, db) — now correct
            await asyncio.to_thread(self._save_chunks, db, project_id, all_chunks, embeddings)

            await emitter.emit("processing", "Chunks saved. Starting agent analysis...", 60)

            # ── MILESTONE 4 CONNECTION ────────────────────────────────────
            # Import here to avoid circular imports at module level.
            # agents/ is outside backend/ so sys.path was extended above.
            from agents.orchestrator import run_agents

            await run_agents(
                project_id=project_id,
                db=db,
                emitter=emitter,
            )
            # orchestrator handles:
            #   - running all agents
            #   - saving results to Project.project_metadata
            #   - setting Project.status = "completed"
            # ─────────────────────────────────────────────────────────────

        finally:
            if temp_dir and os.path.exists(temp_dir):
                shutil.rmtree(temp_dir, ignore_errors=True)

    # ── Source resolution ─────────────────────────────────────────────────
    def _resolve_source(self, source_path: str):
        if source_path.endswith(".zip") or zipfile.is_zipfile(source_path):
            temp_dir = tempfile.mkdtemp(prefix="codeanalysis_")
            with zipfile.ZipFile(source_path, "r") as zf:
                zf.extractall(temp_dir)
            entries = os.listdir(temp_dir)
            if len(entries) == 1:
                candidate = os.path.join(temp_dir, entries[0])
                if os.path.isdir(candidate):
                    return candidate, temp_dir
            return temp_dir, temp_dir
        return source_path, None

    # ── File collection ───────────────────────────────────────────────────
    def _collect_files(self, root: str) -> List[str]:
        result = []
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = [d for d in dirnames if d not in self.SKIP_DIRS]
            for filename in filenames:
                if Path(filename).suffix.lower() in self.CODE_EXTENSIONS:
                    result.append(os.path.join(dirpath, filename))
        return result

    # ── Project type detection ────────────────────────────────────────────
    def _detect_project_type(self, root: str) -> str:
        markers = {
            "package.json":     "Node.js/JavaScript",
            "requirements.txt": "Python",
            "pyproject.toml":   "Python",
            "go.mod":           "Go",
            "pom.xml":          "Java (Maven)",
            "build.gradle":     "Java (Gradle)",
            "Cargo.toml":       "Rust",
            "Gemfile":          "Ruby",
            "composer.json":    "PHP",
        }
        for fname, label in markers.items():
            if os.path.exists(os.path.join(root, fname)):
                return label
        for _, _, files in os.walk(root):
            for f in files:
                if f.endswith(".csproj"):
                    return "C#"
        return "Unknown"

    # ── Chunking ──────────────────────────────────────────────────────────
    def _chunk_file(self, content: str, rel_path: str) -> List[dict]:
        if TREE_SITTER_AVAILABLE and tree_sitter is not None:
            try:
                return self._chunk_by_syntax(content, rel_path)
            except Exception:
                pass
        return self._chunk_by_line(content, rel_path)

    def _chunk_by_line(self, content: str, rel_path: str) -> List[dict]:
        lines = content.splitlines()
        total = len(lines)
        if total == 0:
            return []

        chunks      = []
        start       = 0
        chunk_index = 0

        while start < total:
            end     = min(start + CHUNK_SIZE, total)
            chunk   = {
                "file_path":  rel_path,
                "start_line": start + 1,
                "end_line":   end,
                "chunk_type": "code",
                "name":       f"{rel_path}_chunk{chunk_index}",
                "content":    "\n".join(lines[start:end]),
            }
            chunks.append(chunk)          # FIX: was missing in original
            chunk_index += 1
            next_start = max(end - CHUNK_OVERLAP, start + 1)
            start = next_start

        return chunks

    def _chunk_by_syntax (self, content: str, rel_path: str) -> List[dict]:
        """Tree-sitter based chunking — Python and JS/TS only."""
        ext = Path(rel_path).suffix.lower()

        if ext == ".py":
            from tree_sitter_python import Language as PyLang
            lang = tree_sitter.Language(PyLang())
        elif ext in {".js", ".ts", ".jsx", ".tsx"}:
            from tree_sitter_javascript import Language as JsLang
            lang = tree_sitter.Language(JsLang())           # FIX: was `lan` / `lang` mismatch
        else:
            raise ValueError(f"No tree-sitter grammar for {ext}")

        parser = tree_sitter.Parser(lang)
        tree   = parser.parse(content.encode())

        interesting = {
            "function_definition", "class_definition",
            "function_declaration", "class_declaration",
            "function_expression", "arrow_function",
            "method_definition",   "export_statement",
        }
        chunks = []

        def walk(node):
            if node.type in interesting:
                start_line = node.start_point[0] + 1
                end_line   = node.end_point[0] + 1
                chunk_text = content.encode()[node.start_byte:node.end_byte].decode(errors="replace")   # FIX: errors= not error=
                name_node  = node.child_by_field_name("name")                                           # FIX: was undefined
                node_name  = name_node.text.decode(errors="replace") if name_node else node.type
                chunks.append({
                    "file_path":  rel_path,
                    "start_line": start_line,
                    "end_line":   end_line,
                    "chunk_type": "function" if "function" in node.type else "class",
                    "name":       f"{rel_path}_{node_name}_{start_line}",
                    "content":    chunk_text,
                })
            for child in node.children:
                walk(child)

        walk(tree.root_node)
        return chunks if chunks else self._chunk_by_line(content, rel_path)

    # ── Embeddings ────────────────────────────────────────────────────────
    async def _generate_embeddings(
        self,
        texts: List[str],
        emitter: ProgressEmitter,
    ) -> List[List[float]]:
        openai_key = os.getenv("OPENAI_API_KEY")
        if not openai_key or not OPENAI_AVAILABLE:
            await emitter.emit("warning", "No OpenAI key — using zero embeddings.", 43)
            return [[0.0] * 1536 for _ in texts]

        client      = _openai_module.AsyncOpenAI(api_key=openai_key)
        embeddings  = []
        batch_size  = 100
        total_batches = max(1, (len(texts) + batch_size - 1) // batch_size)

        for batch_idx in range(0, len(texts), batch_size):
            batch         = texts[batch_idx: batch_idx + batch_size]
            current_batch = batch_idx // batch_size + 1
            pct           = 42 + (current_batch / total_batches) * 13   # 42 → 55

            await emitter.emit(
                "processing",
                f"Embeddings batch {current_batch}/{total_batches}",
                pct,
            )
            try:
                resp = await client.embeddings.create(
                    model="text-embedding-3-small",
                    input=batch,
                )
                for item in resp.data:
                    embeddings.append(item.embedding)
            except Exception as exc:
                await emitter.emit("warning", f"Batch {current_batch} failed: {exc}", pct)
                embeddings.extend([[0.0] * 1536] * len(batch))

        return embeddings

    # ── DB save ───────────────────────────────────────────────────────────
    def _save_chunks(
        self,
        db: Session,
        project_id: str,
        chunks: List[dict],
        embeddings: List[List[float]],
    ) -> None:
        # FIX: argument order was swapped at call site in original
        for chunk_data, embedding in zip(chunks, embeddings):
            db.add(Codechunk(
                project_id=project_id,
                file_path=chunk_data["file_path"],
                start_line=chunk_data["start_line"],
                end_line=chunk_data["end_line"],
                chunk_type=chunk_data["chunk_type"],
                name=chunk_data["name"],
                content=chunk_data["content"],
                embedding=embedding,
            ))
        db.commit()
