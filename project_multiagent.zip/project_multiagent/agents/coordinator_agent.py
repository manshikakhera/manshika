"""
agents/coordinator_agent.py
───────────────────────────
ROLE  : Entry point of the pipeline. Reads the Project record and
        decides which agents to run and what to focus on.

READS FROM YOUR DB:
  - Project.name         (backend/models.py → Project)
  - Project.description
  - Project.personas     (JSON column — ["SDE", "PM"])
  - Project.source_type
  - len(chunks)          (from codechunks table)

WRITES TO CONTEXT:
  - context["plan"]          → dict controlling which agents run next
  - context["exec_summary"]  → shown at top of frontend results page
"""

import os, sys, json

_AGENTS_DIR  = os.path.dirname(os.path.abspath(__file__))
_PROJECT_DIR = os.path.dirname(_AGENTS_DIR)
if _PROJECT_DIR not in sys.path:
    sys.path.insert(0, _PROJECT_DIR)
_BACKEND_DIR = os.path.join(_PROJECT_DIR, "backend")
if os.path.isdir(_BACKEND_DIR) and _BACKEND_DIR not in sys.path:
    sys.path.insert(0, _BACKEND_DIR)

from agents.base_agent import BaseAgent


class CoordinatorAgent(BaseAgent):

    name = "Coordinator"
    system_prompt = """\
You are the coordinator of a multi-agent code analysis system.
Given project metadata, produce a concise analysis plan.

Respond ONLY in valid JSON — no markdown fences, no extra text:
{
  "project_category": "web-api|web-fullstack|cli|library|data-pipeline|mobile|other",
  "complexity": "low|medium|high",
  "run_parser": true,
  "run_understanding": true,
  "run_sde": true,
  "run_pm": true,
  "exec_summary": "2-3 sentence executive summary of what this project appears to be",
  "analysis_focus": ["key area 1", "key area 2"]
}

Rules:
- Always set run_parser and run_understanding to true.
- Set run_sde to true ONLY if "SDE" appears in requested_personas (or list is empty).
- Set run_pm  to true ONLY if "PM"  appears in requested_personas (or list is empty).
"""

    async def run(self, context: dict) -> dict:
        project = context.get("project")
        chunks  = context.get("chunks", [])

        await self._emit("Planning agent pipeline...", percent=25)

        # ── Pull fields from ORM object or plain dict ────────────────────
        def _get(obj, attr, default=""):
            return getattr(obj, attr, None) or (obj.get(attr) if isinstance(obj, dict) else None) or default

        name        = _get(project, "name",        "Unknown")
        description = _get(project, "description", "Not provided")
        personas    = _get(project, "personas",    [])
        source_type = _get(project, "source_type", "unknown")

        # File-extension breakdown — cheap signal for project type
        ext_counts: dict[str, int] = {}
        for chunk in chunks:
            path = _get(chunk, "file_path", "")
            ext  = path.rsplit(".", 1)[-1].lower() if "." in path else "unknown"
            ext_counts[ext] = ext_counts.get(ext, 0) + 1

        prompt = f"""\
Project name        : {name}
Description         : {description}
Source type         : {source_type}
Requested personas  : {personas}
Total code chunks   : {len(chunks)}
File-type breakdown : {json.dumps(ext_counts)}

Produce the analysis plan JSON now.
"""
        raw = await self._chat(prompt, model="gpt-4o-mini", max_tokens=600)

        try:
            plan = json.loads(raw.strip())
        except json.JSONDecodeError:
            # Safe fallback
            plan = {
                "project_category": "other",
                "complexity":       "medium",
                "run_parser":       True,
                "run_understanding":True,
                "run_sde":          "SDE" in personas or not personas,
                "run_pm":           "PM"  in personas or not personas,
                "exec_summary":     f"Analysis of {name}.",
                "analysis_focus":   [],
            }

        await self._emit(
            f"Plan ready — {plan.get('project_category')} / {plan.get('complexity')} complexity.",
            percent=30,
        )

        return {
            "agent_name":   self.name,
            "plan":         plan,
            "exec_summary": plan.get("exec_summary", ""),
        }
