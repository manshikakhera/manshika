"""
agents/diagram_agent.py
───────────────────────
ROLE  : Generates Mermaid diagram syntax for the analyzed codebase.

READS FROM CONTEXT:
  - context["understanding"]  → project purpose, tech stack, architecture
  - context["structure"]      → file list
  - context["sde_analysis"]   → architecture observations

WRITES TO CONTEXT:
  - context["diagrams"] → dict with Mermaid strings for 4 diagram types
"""

import os, sys, json

_AGENTS_DIR  = os.path.dirname(os.path.abspath(__file__))
_PROJECT_DIR = os.path.dirname(_AGENTS_DIR)
if _PROJECT_DIR not in sys.path:
    sys.path.insert(0, _PROJECT_DIR)
_BACKEND_DIR = os.path.join(_PROJECT_DIR, "backend")
if os.path.isdir(_BACKEND_DIR) and _BACKEND_DIR not in sys.path:
    sys.path.insert(0, _BACKEND_DIR)

from agents.base_agent import BaseAgent


class DiagramAgent(BaseAgent):

    name = "Diagram Generator"
    system_prompt = """\
You are a software architect who creates Mermaid diagram syntax.
Given project information, generate 4 Mermaid diagrams.

Respond ONLY in valid JSON with exactly these keys — no markdown fences, no extra text:
{
  "architecture": "<valid mermaid graph TD syntax>",
  "data_flow":    "<valid mermaid flowchart LR syntax>",
  "sequence":     "<valid mermaid sequenceDiagram syntax>",
  "er_diagram":   "<valid mermaid erDiagram or classDiagram syntax>"
}

Rules:
- Use \\n for newlines within each diagram string
- Keep diagrams concise (max 20 nodes)
- Use actual component names from the codebase
- Every diagram string must be valid standalone Mermaid syntax
"""

    async def run(self, context: dict) -> dict:
        understanding = context.get("understanding", {})
        structure     = context.get("structure", {})
        sde_analysis  = context.get("sde_analysis", {})

        await self._emit("Generating Mermaid diagrams...", percent=84)

        files = structure.get("files", [])[:25]
        arch_obs = sde_analysis.get("architecture_observations", [])

        prompt = f"""\
Project understanding:
{json.dumps(understanding, indent=2)[:1200]}

File structure (sample):
{json.dumps(files, indent=2)[:600]}

Architecture observations:
{json.dumps(arch_obs, indent=2)[:400]}

Generate all 4 Mermaid diagrams now. Return only the JSON object.
"""
        raw = await self._chat(prompt, model="gpt-4o-mini", max_tokens=2000, temperature=0.2)

        # Strip markdown fences if present
        if "```json" in raw:
            raw = raw.split("```json")[1].split("```")[0].strip()
        elif "```" in raw:
            raw = raw.split("```")[1].split("```")[0].strip()

        try:
            result = json.loads(raw)
        except json.JSONDecodeError:
            result = {
                "architecture": "graph TD\n  A[System] --> B[Unknown]",
                "data_flow":    "flowchart LR\n  Input --> Process --> Output",
                "sequence":     "sequenceDiagram\n  Client->>Server: Request\n  Server-->>Client: Response",
                "er_diagram":   "erDiagram\n  ENTITY { string id }",
            }

        await self._emit("Diagrams generated.", percent=90)
        return {"diagrams": result}
