"""
agents/persona_agent.py
───────────────────────
ROLE  : One class that runs as either SDE or PM.
        Persona is passed at construction:  PersonaAgent("SDE") / PersonaAgent("PM")

        SDE output  → code quality, bugs, architecture, security, improvements
        PM  output  → features, user flows, business value, gaps, MVP assessment

READS FROM CONTEXT:
  - context["understanding"]  → from UnderstandingAgent
  - context["structure"]      → from ParserAgent
  - context["chunks"]         → picks most relevant code samples
    (Codechunk.file_path + Codechunk.content — backend/models.py)

WRITES TO CONTEXT:
  - context["sde_analysis"]   if persona == "SDE"
  - context["pm_analysis"]    if persona == "PM"

Both are saved into Project.project_metadata (JSON column) by the orchestrator.
"""

import os, sys, json
from typing import Literal

_AGENTS_DIR  = os.path.dirname(os.path.abspath(__file__))
_PROJECT_DIR = os.path.dirname(_AGENTS_DIR)
if _PROJECT_DIR not in sys.path:
    sys.path.insert(0, _PROJECT_DIR)
_BACKEND_DIR = os.path.join(_PROJECT_DIR, "backend")
if os.path.isdir(_BACKEND_DIR) and _BACKEND_DIR not in sys.path:
    sys.path.insert(0, _BACKEND_DIR)

from agents.base_agent import BaseAgent


# ── Per-persona system prompts ───────────────────────────────────────────────

_SDE_PROMPT = """\
You are a senior software engineer doing a thorough code review.
Analyze the codebase and produce a technical assessment.

Respond ONLY in valid JSON — no markdown fences, no extra text:
{
  "code_quality"             : "good|fair|poor",
  "quality_summary"          : "2-3 sentence overall assessment",
  "potential_bugs"           : [
      {"location": "file or area", "description": "what could go wrong", "severity": "high|medium|low"}
  ],
  "architecture_observations": ["observation 1", "observation 2"],
  "security_concerns"        : ["concern 1", "concern 2"],
  "performance_concerns"     : ["concern 1", "concern 2"],
  "improvement_suggestions"  : [
      {"area": "area name", "suggestion": "what to do", "priority": "high|medium|low"}
  ],
  "positive_aspects"         : ["good thing 1", "good thing 2"]
}
"""

_PM_PROMPT = """\
You are an experienced Product Manager reviewing a codebase to understand the product.
Produce a product-focused analysis.

Respond ONLY in valid JSON — no markdown fences, no extra text:
{
  "product_summary"    : "2-3 sentences: what does this do for users?",
  "features"           : [
      {"name": "feature name", "description": "what it does", "business_value": "why it matters"}
  ],
  "user_flows"         : [
      {"flow": "flow name", "steps": ["step 1", "step 2"]}
  ],
  "target_users"       : ["user type 1", "user type 2"],
  "gaps"               : ["missing capability 1", "missing capability 2"],
  "market_positioning" : "one sentence on where this fits",
  "mvp_assessment"     : "is this MVP-ready? what is missing?"
}
"""


class PersonaAgent(BaseAgent):

    def __init__(self, persona: Literal["SDE", "PM"], emitter=None):
        if persona not in ("SDE", "PM"):
            raise ValueError(f"Unknown persona '{persona}'. Must be 'SDE' or 'PM'.")
        self.persona       = persona
        self.name          = f"{persona} Analyst"
        self.system_prompt = _SDE_PROMPT if persona == "SDE" else _PM_PROMPT
        super().__init__(emitter=emitter)

    async def run(self, context: dict) -> dict:
        understanding = context.get("understanding", {})
        structure     = context.get("structure", {})
        chunks        = context.get("chunks", [])

        # Progress: SDE runs first (65-73%), PM runs second (75-83%)
        pct_start = 65 if self.persona == "SDE" else 75
        await self._emit(f"Analyzing from {self.persona} perspective...", percent=pct_start)

        # ── Select most relevant chunks for this persona ─────────────────
        def relevance(chunk) -> int:
            path = getattr(chunk, "file_path", None) or (chunk.get("file_path", "") if isinstance(chunk, dict) else "")
            if self.persona == "SDE":
                # SDE cares about implementation files
                return 1 if any(path.endswith(e) for e in [".py", ".js", ".ts", ".go", ".java"]) else 0
            else:
                # PM cares about routes, controllers, entry points
                keywords = ["main", "route", "router", "api", "view", "controller", "app", "handler"]
                return sum(1 for k in keywords if k in path.lower())

        top_chunks = sorted(chunks, key=relevance, reverse=True)[:8]

        code_samples = []
        for chunk in top_chunks:
            path    = getattr(chunk, "file_path", None) or (chunk.get("file_path", "?") if isinstance(chunk, dict) else "?")
            content = getattr(chunk, "content",   None) or (chunk.get("content",   "")  if isinstance(chunk, dict) else "")
            code_samples.append(f"--- {path} ---\n{content[:400]}\n")

        prompt = f"""\
Project understanding:
{json.dumps(understanding, indent=2)[:1500]}

Project file structure:
{json.dumps(structure.get("files", [])[:20], indent=2)}

Relevant code samples:
{''.join(code_samples)[:3000]}

Produce your {self.persona} analysis JSON now.
"""
        # Use gpt-4o for persona agents — this is the final user-facing output
        raw = await self._chat(prompt, model="gpt-4o", max_tokens=2500, temperature=0.4)

        try:
            result = json.loads(raw.strip())
        except json.JSONDecodeError:
            result = {"raw_output": raw}

        output_key = "sde_analysis" if self.persona == "SDE" else "pm_analysis"
        await self._emit(f"{self.persona} analysis complete.", percent=pct_start + 8)

        return {
            "agent_name": self.name,
            output_key:   result,
        }
