import json
import os
import time

import requests
import streamlit as st
from dotenv import load_dotenv

load_dotenv()

BACKEND_URL = os.getenv("BACKEND_URL", "http://localhost:8000")
st.set_page_config(page_title="Code Analysis Dashboard", layout="wide")


def init_state():
    defaults = {
        "page": "login",
        "token": None,
        "email": None,
        "current_project_id": None,
        "activity_log": [],
        "progress_percent": 0,
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


init_state()


def auth_headers():
    return {"Authorization": f"Bearer {st.session_state.token}"}


def go_to(page: str):
    st.session_state.page = page
    st.rerun()


def status_badge(status: str) -> str:
    colour = {"pending": "gray", "processing": "blue",
              "completed": "green", "failed": "red"}.get(status, "gray")
    return f'<span style="color:{colour};font-size:16px;">●</span> {status.capitalize()}'


# ── Auth pages ───────────────────────────────────────────────────────────────

def page_login():
    st.title("Login")
    with st.form("login_form"):
        email = st.text_input("Email")
        password = st.text_input("Password", type="password")
        submit = st.form_submit_button("Login")
    if submit:
        if not email or not password:
            st.error("Please enter both email and password.")
        else:
            try:
                r = requests.post(f"{BACKEND_URL}/auth/login",
                                  json={"email": email, "password": password}, timeout=10)
                if r.status_code == 200:
                    st.session_state.token = r.json()["access_token"]
                    st.session_state.email = email
                    go_to("dashboard")
                else:
                    st.error("Login failed: " + r.json().get("detail", "Unknown error"))
            except requests.exceptions.ConnectionError:
                st.error("Cannot reach the backend.")
    st.markdown("---")
    if st.button("Don't have an account? Sign up"):
        go_to("signup")


def page_signup():
    st.title("Sign Up")
    with st.form("signup_form"):
        email = st.text_input("Email")
        password = st.text_input("Password", type="password")
        confirm = st.text_input("Confirm Password", type="password")
        submit = st.form_submit_button("Sign Up")
    if submit:
        if not email or not password or not confirm:
            st.error("All fields are required.")
        elif password != confirm:
            st.error("Passwords do not match.")
        else:
            try:
                r = requests.post(f"{BACKEND_URL}/auth/signup",
                                  json={"email": email, "password": password}, timeout=10)
                if r.status_code in (200, 201):
                    st.success("Signup successful! Please login.")
                    go_to("login")
                else:
                    st.error("Signup failed: " + r.json().get("detail", "Unknown error"))
            except requests.exceptions.ConnectionError:
                st.error("Cannot reach the backend.")
    st.markdown("---")
    if st.button("Already have an account? Login"):
        go_to("login")


# ── Dashboard ────────────────────────────────────────────────────────────────

def page_dashboard():
    col1, col2 = st.columns([8, 2])
    col1.title(f"Welcome, {st.session_state.email}")
    with col2:
        if st.button("+ New Project"):
            go_to("upload")
        if st.button("Logout"):
            st.session_state.token = None
            st.session_state.email = None
            go_to("login")

    admin_email = os.getenv("ADMIN_EMAIL", "admin@example.com")
    if st.session_state.email == admin_email:
        if st.button("Admin Panel"):
            go_to("admin")

    st.subheader("Your Projects")
    try:
        r = requests.get(f"{BACKEND_URL}/projects/", headers=auth_headers(), timeout=10)
        if r.status_code == 401:
            go_to("login")
            return
        projects = r.json() if r.status_code == 200 else []
    except requests.exceptions.ConnectionError:
        st.error("Cannot reach the backend.")
        return

    if not projects:
        st.info("No projects yet. Create your first one!")
        return

    header_cols = st.columns([4, 3, 2, 2, 1])
    for label, col in zip(["Name", "Description", "Personas", "Status", ""], header_cols):
        col.markdown(f"**{label}**")
    st.markdown("---")

    for p in projects:
        row = st.columns([4, 3, 2, 2, 1])
        row[0].write(p.get("name", "-"))
        row[1].write((p.get("description") or "-")[:60])
        row[2].write(", ".join(p.get("personas") or []) or "-")
        row[3].markdown(status_badge(p.get("status", "pending")), unsafe_allow_html=True)
        if row[4].button("View", key=f"view_{p['id']}"):
            st.session_state.current_project_id = p["id"]
            st.session_state.activity_log = []
            st.session_state.progress_percent = 0
            go_to("project_detail")


# ── Upload / create project ──────────────────────────────────────────────────

def page_upload():
    st.title("Create New Project")
    if st.button("Back"):
        go_to("dashboard")

    with st.form("upload_form"):
        project_name = st.text_input("Project Name")
        description = st.text_area("Description")
        st.markdown("**Select Personas**")
        sde = st.checkbox("SDE (Software Engineer)")
        pm = st.checkbox("PM (Product Manager)")
        tab_zip, tab_gh = st.tabs(["Upload ZIP", "GitHub URL"])
        with tab_zip:
            uploaded_file = st.file_uploader("Upload ZIP file", type=["zip"])
        with tab_gh:
            github_url = st.text_input("GitHub Repository URL")
        submitted = st.form_submit_button("Create & Analyse")

    if not submitted:
        return

    if not project_name:
        st.error("Project name is required.")
        return
    personas = []
    if sde:
        personas.append("SDE")
    if pm:
        personas.append("PM")
    if not personas:
        st.error("Select at least one persona.")
        return
    source = "zip" if uploaded_file else ("github" if github_url else None)
    if source is None:
        st.error("Upload a ZIP file or provide a GitHub URL.")
        return

    try:
        cr = requests.post(
            f"{BACKEND_URL}/projects/",
            headers=auth_headers(),
            json={"name": project_name, "description": description, "personas": personas},
            timeout=15,
        )
    except Exception as exc:
        st.error(f"Failed to create project: {exc}")
        return
    if cr.status_code not in (200, 201):
        st.error(f"Failed to create project: {cr.json().get('detail')}")
        return

    project_id = cr.json()["id"]
    try:
        if source == "zip":
            upload_resp = requests.post(
                f"{BACKEND_URL}/projects/{project_id}/upload",
                headers=auth_headers(),
                files={"file": (uploaded_file.name, uploaded_file.getvalue(), "application/zip")},
                timeout=60,
            )
        else:
            upload_resp = requests.post(
                f"{BACKEND_URL}/projects/{project_id}/upload?github_url={github_url}",
                headers=auth_headers(),
                timeout=60,
            )
    except Exception as exc:
        st.error(f"Failed to upload source: {exc}")
        return
    if upload_resp.status_code not in (200, 201, 202):
        st.error(f"Upload failed: {upload_resp.json().get('detail', 'unknown error')}")
        return

    st.success("Project created! Analysis starting...")
    st.session_state.current_project_id = project_id
    st.session_state.activity_log = []
    st.session_state.progress_percent = 0
    time.sleep(0.5)
    go_to("project_detail")


# ── Project detail ───────────────────────────────────────────────────────────

def page_project_detail():
    project_id = st.session_state.get("current_project_id")
    if not project_id:
        st.error("No project selected.")
        if st.button("Back to Dashboard"):
            go_to("dashboard")
        return

    try:
        r = requests.get(f"{BACKEND_URL}/projects/{project_id}",
                         headers=auth_headers(), timeout=10)
        if r.status_code == 401:
            go_to("login")
            return
        if r.status_code != 200:
            st.error("Could not load project.")
            return
        project = r.json()
    except Exception as exc:
        st.error(f"Error: {exc}")
        return

    if st.button("Dashboard"):
        go_to("dashboard")

    st.title(project.get("name", "Project"))
    if project.get("description"):
        st.write(project["description"])
    personas = project.get("personas") or []
    if personas:
        st.markdown(f"**Personas:** {', '.join(personas)}")
    status = project.get("status", "pending")
    st.markdown(f"**Status:** {status_badge(status)}", unsafe_allow_html=True)
    st.markdown("---")

    if status == "processing":
        st.subheader("Analysis in Progress")
        prog_ph = st.empty()
        log_ph = st.empty()
        try:
            with requests.get(
                f"{BACKEND_URL}/projects/{project_id}/progress",
                headers={**auth_headers(), "Accept": "text/event-stream"},
                stream=True, timeout=6,
            ) as sse:
                if sse.status_code == 200:
                    count = 0
                    for raw in sse.iter_lines():
                        if not raw:
                            continue
                        line = raw.decode() if isinstance(raw, bytes) else raw
                        if not line.startswith("data:"):
                            continue
                        try:
                            ev = json.loads(line[5:].strip())
                            pct = ev.get("percent", 0)
                            if pct > st.session_state.progress_percent:
                                st.session_state.progress_percent = pct
                            msg = ev.get("message", "")
                            if msg and msg not in st.session_state.activity_log:
                                st.session_state.activity_log.append(msg)
                            count += 1
                            if count >= 5:
                                break
                        except (json.JSONDecodeError, KeyError):
                            pass
        except Exception:
            pass
        prog_ph.progress(min(st.session_state.progress_percent / 100.0, 0.99))
        log = st.session_state.activity_log
        log_ph.text_area("Activity Log", "\n".join(log) if log else "Waiting...", height=250)
        time.sleep(2)
        st.rerun()

    elif status == "completed":
        st.success("Analysis complete!")
        try:
            ar = requests.get(f"{BACKEND_URL}/projects/{project_id}/analysis",
                              headers=auth_headers(), timeout=10)
            results = ar.json() if ar.status_code == 200 else {}
        except Exception:
            results = {}

        if not results:
            st.info("No analysis results available yet.")
            return

        tab_summary, tab_sde, tab_pm, tab_diagrams, tab_qa = st.tabs(
            ["Summary", "SDE Report", "PM Report", "Diagrams", "Q&A"]
        )

        with tab_summary:
            exec_sum = results.get("exec_summary", "")
            if exec_sum:
                st.markdown(f"**Executive Summary:** {exec_sum}")
            und = results.get("understanding", {})
            if und:
                st.markdown(f"**Purpose:** {und.get('project_purpose', '-')}")
                stack = und.get("tech_stack", [])
                if stack:
                    st.markdown(f"**Tech Stack:** {', '.join(stack)}")
                st.markdown(f"**Architecture:** {und.get('architecture', '-')}")
                for feat in und.get("core_features", []):
                    st.markdown(f"- {feat}")

        with tab_sde:
            sde = results.get("sde_analysis") or {}
            if not sde:
                st.info("SDE analysis not available.")
            else:
                quality = sde.get("code_quality", "-")
                colour = {"good": "green", "fair": "orange", "poor": "red"}.get(quality, "gray")
                st.markdown(f"**Code Quality:** :{colour}[{quality.upper()}]")
                st.write(sde.get("quality_summary", ""))
                bugs = sde.get("potential_bugs", [])
                if bugs:
                    with st.expander(f"Potential Bugs ({len(bugs)})"):
                        for b in bugs:
                            st.markdown(f"**[{b.get('severity','').upper()}]** `{b.get('location','?')}` -- {b.get('description','')}")
                with st.expander("Architecture Observations"):
                    for o in sde.get("architecture_observations", []):
                        st.markdown(f"- {o}")
                with st.expander("Security Concerns"):
                    for c in sde.get("security_concerns", []):
                        st.markdown(f"- {c}")
                with st.expander("Improvement Suggestions"):
                    for s in sde.get("improvement_suggestions", []):
                        st.markdown(f"**[{s.get('priority','?').upper()}]** {s.get('area','')}: {s.get('suggestion','')}")
                with st.expander("Positive Aspects"):
                    for a in sde.get("positive_aspects", []):
                        st.markdown(f"- {a}")

        with tab_pm:
            pm_data = results.get("pm_analysis") or {}
            if not pm_data:
                st.info("PM analysis not available.")
            else:
                st.write(pm_data.get("product_summary", ""))
                features = pm_data.get("features", [])
                if features:
                    with st.expander(f"Features ({len(features)})"):
                        for f in features:
                            st.markdown(f"**{f.get('name','')}** -- {f.get('description','')}")
                            st.caption(f"Business value: {f.get('business_value','')}")
                flows = pm_data.get("user_flows", [])
                if flows:
                    with st.expander("User Flows"):
                        for fl in flows:
                            st.markdown(f"**{fl.get('flow','')}**")
                            for step in fl.get("steps", []):
                                st.markdown(f"  -> {step}")
                with st.expander("Gaps and Limitations"):
                    for g in pm_data.get("gaps", []):
                        st.markdown(f"- {g}")
                st.markdown(f"**Market Positioning:** {pm_data.get('market_positioning','')}")
                st.info(f"**MVP Assessment:** {pm_data.get('mvp_assessment','')}")

        with tab_diagrams:
            diagrams = results.get("diagrams") or {}
            if not diagrams:
                st.info("Diagrams not available.")
            else:
                for key, label in [("architecture", "Architecture"), ("data_flow", "Data Flow"),
                                   ("sequence", "Sequence Diagram"), ("er_diagram", "ER / Class Diagram")]:
                    code = diagrams.get(key, "")
                    if code:
                        st.markdown(f"#### {label}")
                        st.code(code, language="text")
                        st.caption("Paste into mermaid.live to render visually.")
                        st.markdown("---")

        with tab_qa:
            st.markdown("Ask any question about the analyzed codebase.")
            question = st.text_input("Your question", key="qa_input",
                                     placeholder="e.g. How does authentication work?")
            if st.button("Ask", key="qa_ask") and question:
                with st.spinner("Thinking..."):
                    try:
                        qa_r = requests.post(
                            f"{BACKEND_URL}/projects/{project_id}/qa",
                            headers=auth_headers(),
                            json={"question": question},
                            timeout=30,
                        )
                        if qa_r.status_code == 200:
                            data = qa_r.json()
                            st.markdown("**Answer:**")
                            st.write(data["answer"])
                            refs = data.get("references", [])
                            if refs:
                                with st.expander("Code References"):
                                    for ref in refs:
                                        st.markdown(f"- `{ref['file']}` lines {ref['lines']}")
                        else:
                            st.error(f"Q&A failed: {qa_r.json().get('detail','')}")
                    except Exception as exc:
                        st.error(f"Error: {exc}")

    elif status == "failed":
        st.error("Analysis failed.")
        meta = project.get("project_metadata") or {}
        if isinstance(meta, dict) and meta.get("error"):
            st.code(meta["error"])
    else:
        st.info("Project is queued and will start processing shortly.")
        time.sleep(3)
        st.rerun()


# ── Admin panel ──────────────────────────────────────────────────────────────

def page_admin():
    st.title("Admin Panel")
    if st.button("Dashboard"):
        go_to("dashboard")

    try:
        sr = requests.get(f"{BACKEND_URL}/admin/stats", headers=auth_headers(), timeout=10)
        if sr.status_code == 403:
            st.error("Admin access required.")
            go_to("dashboard")
            return
        stats = sr.json() if sr.status_code == 200 else {}
    except Exception as exc:
        st.error(f"Error: {exc}")
        return

    if stats:
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Total Users", stats.get("total_users", 0))
        c2.metric("Total Projects", stats.get("total_projects", 0))
        c3.metric("Completed", stats.get("completed_projects", 0))
        c4.metric("Completion Rate", f"{stats.get('completion_rate', 0)}%")

    st.markdown("---")
    tab_users, tab_projects = st.tabs(["Users", "Projects"])

    with tab_users:
        ur = requests.get(f"{BACKEND_URL}/admin/users", headers=auth_headers(), timeout=10)
        users = ur.json() if ur.status_code == 200 else []
        for u in users:
            c_email, c_date, c_del = st.columns([4, 3, 1])
            c_email.write(u.get("email", "-"))
            c_date.write(str(u.get("created_at", ""))[:10])
            if c_del.button("Delete", key=f"del_u_{u['id']}"):
                dr = requests.delete(f"{BACKEND_URL}/admin/users/{u['id']}",
                                     headers=auth_headers(), timeout=10)
                if dr.status_code == 200:
                    st.rerun()

    with tab_projects:
        pr = requests.get(f"{BACKEND_URL}/admin/projects", headers=auth_headers(), timeout=10)
        all_proj = pr.json() if pr.status_code == 200 else []
        for p in all_proj:
            c_n, c_s, c_d = st.columns([4, 2, 1])
            c_n.write(p.get("name", "-"))
            c_s.markdown(status_badge(p.get("status", "pending")), unsafe_allow_html=True)
            if c_d.button("Delete", key=f"del_p_{p['id']}"):
                dr = requests.delete(f"{BACKEND_URL}/admin/projects/{p['id']}",
                                     headers=auth_headers(), timeout=10)
                if dr.status_code == 200:
                    st.rerun()


# ── Router ───────────────────────────────────────────────────────────────────

def main():
    page = st.session_state.page
    if page in {"dashboard", "upload", "project_detail", "admin"} and not st.session_state.token:
        go_to("login")
        return
    {
        "login": page_login,
        "signup": page_signup,
        "dashboard": page_dashboard,
        "upload": page_upload,
        "project_detail": page_project_detail,
        "admin": page_admin,
    }.get(page, page_login)()


if __name__ == "__main__":
    main()
